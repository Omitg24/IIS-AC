/*
 * Main.cpp
 *
 *  Created on: Fall 2019
 */

#include <stdio.h>
#include <math.h>
#include <CImg.h>
#include <errno.h>
#include <fstream>

using namespace cimg_library;

// Data type for image components
// FIXME: Change this type according to your group assignment
typedef float data_t;

const char* SOURCE_IMG      = "bailarina.bmp";
const char* SOURCE_IMG2      = "flores_3.bmp";
const char* DESTINATION_IMG = "bailarina2.bmp";

bool check_pictures(const char *pictureName){
	std::ifstream picture(pictureName);
	return picture.good();
}


int main() {
	//Check if the pictures exist
	if(check_pictures(SOURCE_IMG) == false){
		perror("Source Picture 1 doesn't exist");
		exit(0);
	}
	if(check_pictures(SOURCE_IMG2) == false){
		perror("Source Picture 2 doesn't exist");
		exit(0);
	}

	// Open file and object initialization
	CImg<data_t> srcImage(SOURCE_IMG);
	CImg<data_t> srcImage2(SOURCE_IMG2);

	data_t *pRsrc, *pGsrc, *pBsrc; // Pointers to the R, G and B components
	data_t *pRsrc2, *pGsrc2, *pBsrc2;
	data_t *pRdest, *pGdest, *pBdest;
	data_t *pDstImage; // Pointer to the new image pixels
	uint width, height; // Width and height of the image
	uint width2, height2; // Width and height of the image
	uint nComp; // Number of image components


	/***************************************************
	 * TODO: Variables initialization.
	 *   - Prepare variables for the algorithm
	 *   - This is not included in the benchmark time
	 */

	
	//srcImage.display();
	//srcImage2.display(); // Displays the source image
	width  = srcImage.width(); // Getting information from the source image
	height = srcImage.height();
	nComp  = srcImage.spectrum(); // source image number of components
	width2  = srcImage2.width(); // 
	height2 = srcImage2.height();

				// Common values for spectrum (number of image components):
				//  B&W images = 1
				//	Normal color images = 3 (RGB)
				//  Special color images = 4 (RGB and alpha/transparency channel)


	// Allocate memory space for destination image components
	pDstImage = (data_t *) malloc (width * height * nComp * sizeof(data_t));
	if (pDstImage == NULL) {
		perror("Allocating destination image");
		exit(-2);
	}
	
	if((width * height) != (width2 * height2)){
		perror("The size of the images is different");
		exit(0);
	}	

	/***********************************************
	 * TODO: Algorithm start.
	 *   - Measure initial time
	 */
	struct timespec tStart, tEnd;
	double dElapsedTimeS;

	if(clock_gettime(CLOCK_REALTIME, &tStart)!=0)
	{
		printf("ERROR: clock_gettime: %d. \n", errno);
		exit(EXIT_FAILURE);
	}

	/************************************************
	 * FIXME: Algorithm.
	 * In this example, the algorithm is a components swap
	 *
	 * TO BE REPLACED BY YOUR ALGORITHM
	 */
	
	int npix = height * width;

	//Loop to check time between 4-8 seconds
	int nRepeats = 4;
	for(int j=0;j<nRepeats;j++){

		// Pointers to the RGB arrays of the source image
		pRsrc = srcImage.data(); // pRcomp points to the R component array
		pGsrc = pRsrc + height * width; // pGcomp points to the G component array
		pBsrc = pGsrc + height * width; // pBcomp points to B component array
		pRsrc2 = srcImage2.data();		 // pRcomp points to the R component array
		pGsrc2 = pRsrc2 + height2 * width2; // pGcomp points to the G component array
		pBsrc2 = pGsrc2 + height2 * width2;

		// Pointers to the RGB arrays of the destination image
		pRdest = pDstImage;
		pGdest = pRdest + height * width;
		pBdest = pGdest + height * width;
		for(int i = 0; i<npix ;i++){
			*pRdest = (sqrt((*pRsrc * *pRsrc)+(*pRsrc2 * *pRsrc2)))/sqrt(2);
			*pGdest = (sqrt((*pGsrc * *pGsrc)+(*pGsrc2 * *pGsrc2)))/sqrt(2);
			*pBdest = (sqrt((*pBsrc * *pBsrc)+(*pBsrc2 * *pBsrc2)))/sqrt(2);
	
			pRsrc ++;
			pGsrc ++;
			pBsrc ++;
			pRsrc2 ++;
			pGsrc2 ++;
			pBsrc2 ++;
			pRdest ++;
			pGdest ++;
			pBdest ++;
		}
	}
	
	/***********************************************
	 * TODO: End of the algorithm.
	 *   - Measure the end time
	 *   - Calculate the elapsed time
	 */
	if(clock_gettime(CLOCK_REALTIME, &tEnd) !=0)
	{
		printf("ERROR: clock_gettime: %d. \n", errno);
		exit(EXIT_FAILURE);
	}
	dElapsedTimeS = (tEnd.tv_sec - tStart.tv_sec);
	dElapsedTimeS += (tEnd.tv_nsec - tStart.tv_nsec)/1e+9;
	printf("Elapsed time 	: %f s.\n", dElapsedTimeS);	
	// Create a new image object with the calculated pixels
	// In case of normal color images use nComp=3,
	// In case of B/W images use nComp=1.
	CImg<data_t> dstImage(pDstImage, width, height, 1, nComp);

	// Store destination image in disk
	dstImage.save(DESTINATION_IMG); 

	// Display destination image
	//dstImage.display();
	
	// Free memory
	free(pDstImage);

	return 0;
}
